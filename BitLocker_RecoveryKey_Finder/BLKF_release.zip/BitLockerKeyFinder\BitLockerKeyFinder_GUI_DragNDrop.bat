@echo off
REM ====================================================================
REM  BitLockerKeyFinder_GUI_DragNDrop.bat  —  drag & drop images.
REM  Opens the dashboard (loopback). Drag image files/folders onto the
REM  page, or click "Choose files". No Administrator needed for images.
REM ====================================================================
cd /d "%~dp0"
BitLockerKeyFinder_CLI.exe --gui %*
