# BitLocker Recovery Key Finder — User Guide

Recovers BitLocker 48-digit recovery keys that were **saved** on a disk — from disk
images and from disks directly, including deleted and hidden copies. It does not
crack anything; it only finds keys that were already saved.

> For authorized forensic examination only.

Everything is in the single `BitLockerKeyFinder_CLI.exe`. No install, no Python needed.

## Three ways to use it

### 1. Scan a disk image (.E01 / .dd / .raw / .vmdk / .vhdx)
Drag the image file onto `BitLockerKeyFinder_CLI.exe`, or drop it on the dashboard.
Results are written next to the image.

### 2. Scan this computer's disks (dashboard)
Double-click **`Local Scanning_GUI.bat`** (accept the Administrator / UAC prompt —
raw disk access needs it). A browser opens:
- Pick a **physical disk** or **volume** from "Disks on this machine".
- Click **Scan selected (no copy)**.
- Keys appear in a tree: **disk -> folder -> file -> key** (deleted keys grouped by
  offset). Download any item with its **Get** button, or **Download all (.zip)**.

If you decline the Administrator prompt it still opens, but then only image files
can be scanned (physical disks need admin). You can also scan an image from the
command line with `BitLockerKeyFinder_CLI.exe`.

### 3. Shared server (your team sets this up on one machine)
An administrator runs `Start Server.bat` on a server. Everyone else just opens the
link in a browser (e.g. `http://<server>/`) and **drags their disk image onto the
page**. The server scans it and deletes the uploaded copy as soon as it finishes.
You see only your own uploads.

## Results

Written to the results folder (default `BLKF_results`):

```
<name>_bitlocker_keys.txt    readable: KEY + Recovery Key ID + SOURCE + LOCATION
<name>_bitlocker_keys.json   same data as JSON
```

Match the **Recovery Key ID** to your locked volume, then enter the 48-digit **KEY**.

## Notes

- SmartScreen may warn on first run: **More info -> Run anyway**.
- Scanning a large physical disk takes time; progress and estimated time are shown.
- Use this only on media you are authorized to examine.
