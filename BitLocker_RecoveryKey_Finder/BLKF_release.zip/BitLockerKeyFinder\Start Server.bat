@echo off
REM ====================================================================
REM  Start Server.bat  —  shared server for the intranet.
REM  Run on ONE server machine. Colleagues open the printed link in a
REM  browser and drag their images onto the page; the server scans them
REM  and deletes each uploaded copy when its scan finishes. Each user
REM  sees only their own uploads. Edit the port / --out-dir if needed.
REM ====================================================================
cd /d "%~dp0"
BitLockerKeyFinder_CLI.exe --gui --server --port 8700 --workers 32 %*
pause
