@echo off
REM ====================================================================
REM  Local Scanning_GUI.bat  —  scan THIS machine's disks (dashboard).
REM  Opens the web dashboard; pick a physical disk or volume and scan it
REM  in place. Physical-disk access needs Administrator, so this
REM  self-elevates via UAC. If you decline, it still opens for images.
REM ====================================================================
cd /d "%~dp0"
net session >nul 2>&1
if %errorlevel%==0 goto run
echo Requesting Administrator rights (for physical-disk access)...
powershell -NoProfile -Command "try { Start-Process -Verb RunAs -FilePath '%~f0' } catch { exit 1 }"
if not errorlevel 1 exit /b
echo Continuing without Administrator - image files only (physical disks need admin).
:run
BitLockerKeyFinder_CLI.exe --gui %*
